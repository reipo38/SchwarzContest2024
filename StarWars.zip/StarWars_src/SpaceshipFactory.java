public class SpaceshipFactory {
    private static XWing createXWing(String name, boolean isRebel, int shieldCapacity, int blasterDamage, int speed, boolean lightSpeedModule, int maneuverability){
        return new XWing(name, isRebel, shieldCapacity, blasterDamage, speed, lightSpeedModule, maneuverability);
    }
    private static StarDestroyer createStarDestroyer(String name, boolean isRebel, int shieldCapacity, int blasterDamage, int speed, boolean lightSpeedModule, int crewCapacity, int amountOfGuns){
        return new StarDestroyer(name, isRebel, shieldCapacity, blasterDamage, speed, lightSpeedModule, crewCapacity, amountOfGuns);
    }
    public static void main(String[] args) {
        XWing ship1 = createXWing("Pesho", false, 100, 50, 40, false, 10);
        XWing ship2 = createXWing("Dimitur", true, 50, 100, 40, false, 20);
        StarDestroyer ship3 = createStarDestroyer("Nikolay", true, 1000, 30, 10, true, 30, 500);
        ship1.fight(ship2);
    }
}
