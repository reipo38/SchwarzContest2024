public class StarDestroyer extends Battleship{
    private final int crewCapacity;
    private final int amountOfGuns;
    public StarDestroyer(String name, boolean isRebel, int shieldCapacity, int blasterDamage, int speed, boolean lightSpeedModule, int crewCapacity, int amountOfGuns){
        super(name, isRebel, shieldCapacity, blasterDamage, speed, lightSpeedModule);
        this.crewCapacity = crewCapacity;
        this.amountOfGuns = amountOfGuns;
    }
    public void deployTroops(String destination){
        if (hasLightSpeedModule()){
            System.out.println("Star Destroyer " + getName() + " enters lightspeed hyperspace en route to " + destination);
        } else {
            System.out.println(getName() + " deploys troops to " + destination);
        }
    }
    @Override
    public void travel(String destination){

    }
    @Override
    public void fight(Battleship ship){
        if (ship instanceof StarDestroyer){
            fightSD((StarDestroyer) ship);
        }
    }
    public void fightSD(StarDestroyer ship){
        if (this.isRebel() == ship.isRebel()){
            return;
        }
        if (getBlasterDamage() * getAmountOfGuns() > ship.getShieldCapacity()){
            System.out.println("Victory!");
        } else if (ship.getBlasterDamage() * ship.getAmountOfGuns() >getShieldCapacity()){
            System.out.println("Defeat!");
        } else {
            System.out.println("Both ships damaged!");
        }
    }
    private int getAmountOfGuns(){
        return amountOfGuns;
    }
}
