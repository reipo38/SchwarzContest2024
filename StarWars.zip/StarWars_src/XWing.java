public class XWing extends Battleship{
    private final int maneuverability;
    public XWing(String name, boolean isRebel, int shieldCapacity, int blasterDamage, int speed, boolean lightSpeedModule, int maneuverability){
        super(name, isRebel, shieldCapacity, blasterDamage, speed, lightSpeedModule);
        this.maneuverability = maneuverability;
    }
    @Override
    public void travel(String destination){
        System.out.println("XWing " + this.getName() + "is en route to " + destination);
    }
    @Override
    public void fight(Battleship ship){
        if (ship instanceof XWing){
            fightX((XWing) ship);
        }
    }
    private void fightX(XWing ship){
        if (this.isRebel() == ship.isRebel()){
            return;
        }
        if (this.getBlasterDamage() > ship.getShieldCapacity()){
            System.out.println("Victory!");
        } else if (this.getShieldCapacity() < ship.getBlasterDamage()){
            System.out.println("Defeat!");
        } else {
            System.out.println(evade(ship) ? "Battle Evaded!" : "Defeat!");
        }
    }
    public boolean evade(XWing ship){
        return maneuverability > ship.getManeuverability();
    }
    public int getManeuverability(){
        return maneuverability;
    }
}
