public abstract class Battleship {
    private final String name;
    private final boolean isRebel;
    private final int shieldCapacity;
    private final int blasterDamage;
    private final int speed;
    private boolean lightSpeedModule;
    public Battleship(String name, boolean isRebel, int shieldCapacity, int blasterDamage, int speed, boolean lightSpeedModule){
        this.name = name;
        this.isRebel = isRebel;
        this.shieldCapacity = shieldCapacity;
        this.blasterDamage = blasterDamage;
        this.speed = speed;
        this.lightSpeedModule = lightSpeedModule;
    }
    public abstract void travel(String destination);
    public abstract void fight(Battleship ship);

    public String getName() {
        return name;
    }
    public boolean isRebel(){
        return isRebel;
    }

    public int getShieldCapacity() {
        return shieldCapacity;
    }
    public int getBlasterDamage(){
        return blasterDamage;
    }
    public boolean hasLightSpeedModule(){
        return lightSpeedModule;
    }
}
